<?php

namespace Catalog\Notify\Model\ResourceModel\CatalogProductNotificationDetails\Grid;

use Magento\Framework\Data\Collection\Db\FetchStrategyInterface as FetchStrategy;
use Magento\Framework\Data\Collection\EntityFactoryInterface as EntityFactory;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;
use Psr\Log\LoggerInterface as Logger;
//use Magento\Framework\App\RequestInterface;



class Collection extends SearchResult
{

    protected $request;


    public function __construct(
        EntityFactory $entityFactory, Logger $logger, FetchStrategy $fetchStrategy, EventManager $eventManager,
     
        array $data = array(),
        $mainTable = 'product_alert_notify_data',
        $resourceModel = 'Magento\Quote\Model\ResourceModel\Quote',
        $identifierName = null, $connectionName = null
    )
    {
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $mainTable, $resourceModel, $identifierName, $connectionName);
    }

    public function _initSelect()
    {


        parent::_initSelect();

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('32');

   
     
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();  
        $request = $objectManager->get('Magento\Framework\App\Request\Http');  
        $param = $request->getParam('id');
      
        echo $param;

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('product_alert_notify_details'); //gives table name with prefix
      
         $sql = "SELECT * FROM `product_alert_notify_details` WHERE `notify_product_id` = ".$param." ORDER BY 
         product_notify_details_id DESC LIMIT 5";
       //  $logger->info($sql);
       
         $result = $connection->fetchAll($sql);
            // echo "<pre>";
          print_r($result);
          return $result;
  
       
      
    }
}
?>