<?php

namespace Catalog\Notify\Block\Adminhtml;

use Magento\Customer\Block\Adminhtml\Edit\GenericButton;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
use Catalog\Notify\Model\CatalogStockNotifyProductFactory;

class CustomButton extends GenericButton implements ButtonProviderInterface {

    protected $_customerRepository;

    /**
     * @var AccountManagementInterface
     */
    protected $customerAccountManagement;
    protected $catalogStockNotifyProductFactory;
    /**
     * Constructor
     *
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param AccountManagementInterface $customerAccountManagement
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context               $context,
        \Magento\Framework\Registry                         $registry,
        \Magento\Customer\Api\AccountManagementInterface    $customerAccountManagement,
        \Magento\Customer\Api\CustomerRepositoryInterface   $customerRepository,
        catalogStockNotifyProductFactory $catalogStockNotifyProductFactory
    ) {
        parent::__construct($context, $registry);
        $this->customerAccountManagement    = $customerAccountManagement;
        $this->_customerRepository          = $customerRepository;
        $this->catalogStockNotifyProductFactory = $catalogStockNotifyProductFactory;
    }

    public function getButtonData()
    {

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);


        $notifycollectionData = $this->catalogStockNotifyProductFactory->create()
        ->getCollection();
     
        foreach($notifycollectionData as $rowData){
            $customer_awaiting_notification =  $rowData['customer_awaiting_notification'];
            $logger->info(print_r($customer_awaiting_notification,true));
       
        $customer = $customer_awaiting_notification;

        // confirm message
        $message = __('Are you sure you want to do this?');
       // $logger->info(print_r($message,true));
        if ($customer)
        {
            return [
                'label' => __('Custom Button'),
                'on_click' => "confirmSetLocation('{$message}', '{$this->getCustomUrl()}')",
               // 'on_click' => "alert('Hello')",
                'sort_order' => 100
            ];
        }

        return;
    }
    }

    /**
     * URL getter
     *
     * @return string
     */
    public function getCustomUrl()
    {
        return $this->getUrl('custom/index/custom', ['customer_awaiting_notification' => $customer_awaiting_notification]);
    }
}