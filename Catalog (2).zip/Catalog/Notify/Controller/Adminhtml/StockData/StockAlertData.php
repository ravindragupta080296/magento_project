<?php

namespace Catalog\Notify\Controller\Adminhtml\StockData;

class StockAlertData extends \Magento\Backend\App\Action
{
	protected $resultPageFactory = false;

	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory
	)
	{
		parent::__construct($context);
		$this->resultPageFactory = $resultPageFactory;
	}

	public function execute()
	{
	
		$resultPage = $this->resultPageFactory->create();

			
        // $urlInterface = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\UrlInterface');
        // $url = $urlInterface->getCurrentUrl();
		// echo $url;
		// die;
	
		$resultPage->getConfig()->getTitle()->prepend((__('Notify Data ')));

		return $resultPage;
	}


}