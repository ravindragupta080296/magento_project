<?php
namespace Catalog\Notify\Model\ResourceModel\CatalogStockNotifyProduct;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    protected $_idFieldName = 'product_notify_data_id ';
	
	protected $_eventPrefix = 'notify_stockalert_collection';

    protected $_eventObject = 'CatalogStockNotifyProduct_collection';

    public function _construct()
    {
        $this->_init("Catalog\Notify\Model\CatalogStockNotifyProduct", "Catalog\Notify\Model\ResourceModel\CatalogStockNotifyProduct");
    }
}
