<!-- <?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
// namespace Catalog\Notify\Ui\Component\Listing\Column;

// use Magento\Framework\View\Element\UiComponent\ContextInterface;
// use Magento\Framework\View\Element\UiComponentFactory;
// use Magento\Ui\Component\Listing\Columns\Column;
// use Magento\Framework\UrlInterface;
// use Catalog\Notify\Model\CatalogStockNotifyProductFactory;
// use  Magento\Catalog\Api\ProductRepositoryInterface;
/**
 * Class ProductActions
 *
 * @api
 * @since 100.0.2
 */
// class Sendmail extends Column
// {
//     /**
//      * @var UrlInterface
//      */
//     private $productRepository; 

//     protected $urlBuilder;

//     public $layout;

//     protected $catalogStockNotifyProductFactory;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    // public function __construct(
    //     ProductRepositoryInterface $productRepository,
    //     ContextInterface $context,
    //     UiComponentFactory $uiComponentFactory,
    //     catalogStockNotifyProductFactory $catalogStockNotifyProductFactory,
    //     UrlInterface $urlBuilder,
    //     \Magento\Framework\View\LayoutInterface $layout,
    //     array $components = [],
    //     array $data = []
    // ) {
    //     $this->productRepository = $productRepository;
    //     $this->urlBuilder = $urlBuilder;
    //     $this->layout = $layout;
    //     $this->catalogStockNotifyProductFactory = $catalogStockNotifyProductFactory;
    //     parent::__construct($context, $uiComponentFactory, $components, $data,$catalogStockNotifyProductFactory);
    // }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */


//     public function prepareDataSource(array $dataSource)
//     {

//         $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
//         $logger = new \Zend\Log\Logger();
//         $logger->addWriter($writer);

//         if (isset($dataSource['data']['items'])) {
           
//             $storeId = $this->context->getFilterParam('store_id');
//             $fieldName = $this->getData('name');

//             foreach ($dataSource['data']['items'] as &$item) {

//                 $logger->info(print_r($item,true));

//                 $product = $this->productRepository->get($item['stock_alert_Product_sku']);
           
//                 $productUrl =$this->urlBuilder->getUrl(
//                     'catalog/product/edit',
//                     ['id' =>  $product->getId() , 'store' => $storeId]
//                 );

//                 $item[$fieldName . '_html'] = "<button><a href =" .  $productUrl . ">" . $item['stock_alert_email_count'] ."</a></button>";
//             }   
//     }
//         return $dataSource;
//     }
// } -->
