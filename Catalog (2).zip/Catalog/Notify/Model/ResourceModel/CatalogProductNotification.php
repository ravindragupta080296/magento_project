<?php
namespace Catalog\Notify\Model\ResourceModel;

class CatalogProductNotification extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context
    ) {
        parent::__construct($context);
    }

    /**
     * Define main table
     */
    protected  function _construct()
    {
        $this->_init("product_alert_notify_data", "product_notify_data_id");
    }
}
