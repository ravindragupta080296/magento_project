<?php
namespace Catalog\Notify\Model\ResourceModel\CatalogProductNotification;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    protected $_idFieldName = 'product_notify_data_id';
	
	protected $_eventPrefix = 'notify_StockData_collection';

    protected $_eventObject = 'CatalogProductNotification_collection';

    public function _construct()
    {
        $this->_init("Catalog\Notify\Model\CatalogProductNotification", "Catalog\Notify\Model\ResourceModel\CatalogProductNotification");
    }
}
