var config = {
    paths: {            
         'myjs': "Catalog_Notify/js/customfile"
      },   
    shim: {
    'myjs': {
        deps: ['jquery']
    }
  }
}