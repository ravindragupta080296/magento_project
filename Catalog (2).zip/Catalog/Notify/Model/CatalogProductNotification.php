<?php 
namespace Catalog\Notify\Model;

class CatalogProductNotification extends \Magento\Framework\Model\AbstractModel
{
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 0;

    const CACHE_TAG = 'product_alert_notify_data';

    protected $_cacheTag = self::CACHE_TAG;

    public function _construct()
    {
		$this->_init("Catalog\Notify\Model\ResourceModel\CatalogProductNotification");
    }
    public function getIdentities()
    {
      return [self::CACHE_TAG . '_' . $this->getId()];
    }

   public function getDefaultValues()
   {
      $values = [];
      return $values;
   }
   public function getAvailableStatuses()
    {
        return [self::STATUS_ENABLED => __('Enabled'), self::STATUS_DISABLED => __('Disabled')];
    }
}
 ?>