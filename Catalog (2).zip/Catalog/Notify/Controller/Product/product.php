<?php

// namespace Catalog\Notify\Controller\Product;

// use Zend\Log\Filter\Timestamp;
// use Magento\Framework\App\Action\Context;
// use Magento\Framework\View\Result\PageFactory;
// use Magento\Framework\Controller\Result\JsonFactory;
// use Catalog\Notify\Model\CatalogProductNotificationFactory;
// use Catalog\Notify\Model\CatalogProductNotificationDetailsFactory;
// use Catalog\Notify\Model\CatalogStockNotifyProductFactory;

// use Magento\Framework\Mail\Template\TransportBuilder;
// use Magento\Framework\Translate\Inline\StateInterface;
// use Magento\Framework\App\Config\ScopeConfigInterface;
// use Magento\Store\Model\StoreManagerInterface;
// use Magento\Framework\Escaper;
// use Magento\Catalog\Model\ProductRepository;
// use Magento\Catalog\Api\ProductRepositoryInterface;
// use Psr\Log\LoggerInterface;



// class productNotify extends \Magento\Framework\App\Action\Action
// {

//   protected $productRepositoryInterface;

//     protected $productRepository;

//     protected $resultPageFactory;

//     protected $resultJsonFactory;

//     protected $catalogStockNotifyProductFactory;

//     protected $catalogProductNotificationFactory;

//     protected $catalogProductNotificationDetailsFactory;

//     protected $_transportBuilder;

//     protected $_inlineTranslation;

//     protected $_scopeConfig;

//     protected $storeManager;

//     protected $_escaper;

//     protected $_logLoggerInterface;

//     public function __construct(
//         Context $context,
//         ProductRepository $productRepository,
//         ProductRepositoryInterface $productRepositoryInterface,
//         PageFactory $resultPageFactory,
//         JsonFactory $resultJsonFactory,
//         CatalogProductNotificationFactory  $catalogProductNotificationFactory,
//         CatalogStockNotifyProductFactory  $catalogStockNotifyProductFactory,
//         CatalogProductNotificationDetailsFactory $catalogProductNotificationDetailsFactory,
//         TransportBuilder $transportBuilder,
//         StateInterface $inlineTranslation,
//         ScopeConfigInterface $scopeConfig,
//         StoreManagerInterface $storeManager,
//         LoggerInterface $loggerInterface,
//         Escaper $escaper,
//         array $data = []



//     ) {


//         parent::__construct($context);

//         $this->productRepository = $productRepository;
//         $this->resultPageFactory = $resultPageFactory;
//         $this->resultJsonFactory = $resultJsonFactory;
//         $this->productRepositoryInterface = $productRepositoryInterface;
//         $this->catalogProductNotificationFactory = $catalogProductNotificationFactory;
//         $this->catalogStockNotifyProductFactory = $catalogStockNotifyProductFactory;
//         $this->catalogProductNotificationDetailsFactory = $catalogProductNotificationDetailsFactory;
      
//         $this->_transportBuilder = $transportBuilder;
//         $this->_inlineTranslation = $inlineTranslation;
//         $this->_scopeConfig = $scopeConfig;
//         $this->_logLoggerInterface = $loggerInterface;
//         $this->storeManager = $storeManager;
//         $this->messageManager = $context->getMessageManager();
//         $this->escaper = $escaper;
//     }
//     public function execute()
//     {
//     $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
//     $logger = new \Zend\Log\Logger();
//     $logger->addWriter($writer);

//     $post = $this->getRequest()->getPostValue();

//     $logger->info(print_r($post,true));


//     $notifyStockData = $this->catalogProductNotificationFactory->create()
//     ->getCollection()
//     ->addFieldToFilter('product_alert_product_sku', $post['notifyProductSku'])
//     ->getData();
   
//     $logger->info(234);
//     foreach($notifyStockData as $notifyStockValue){
    
//       $product_notify_product_id = $notifyStockValue['product_notify_product_id'];
   
   
//       $notifyStockData = $this->catalogProductNotificationDetailsFactory->create()
//       ->getCollection()
//       ->addFieldToFilter('product_id', $product_notify_product_id)
//       ->getData();
   
//       $countEmailData = count($notifyStockData);
//       $logger->info($countEmailData);



//     }
    
//     $notifycollectionData = $this->catalogProductNotificationFactory->create()
//     ->getCollection()
//     ->addFieldToFilter('product_alert_stock_email', $post['notifyEmail'])
//     ->addFieldToFilter('product_alert_product_name', $post['notifyProductName'])
//     ->addFieldToFilter('product_alert_product_sku', $post['notifyProductSku']);

//    $productNotifyCollectionAllData =  $notifycollectionData->getData();
//    $logger->info(print_r($productNotifyCollectionAllData,true));

//     if(!empty($productNotifyCollectionAllData)){
//    foreach($productNotifyCollectionAllData as $productNotifyCollectionData){

//     $logger->info(123);
//         $notification_total_count = $productNotifyCollectionData['product_alert_count'];

//         $stockAlertNotifyEmailTotalCount =   $notification_total_count + 1;
      
//         $data = array('product_alert_count' => $stockAlertNotifyEmailTotalCount);
//         $logger->info(129);
       
//         if ($productNotifyCollectionData['product_notify_data_id']) {

//           $logger->info(133);
//           $model =  $this->catalogProductNotificationFactory
//             ->create();
//           $model->load($productNotifyCollectionData['product_notify_data_id']);

//           $model->addData($data);
//           $saveData = $model->save();
//           if ($saveData){
//             $this->messageManager->addSuccess(__(' Thank you! You are already subscribed to this product. !'));
//           }
//         }
//        }
     
//     }else{
     
//       if(empty($post['notifyEmail'])){
//       $this->messageManager->addSuccess(__(' Please Enter Valid Email !'));
      
//       }else{
//         $data = array(
//           "product_alert_first_name" => $post['notifyFirstName'],
//           "product_alert_last_name" => $post['notifyLastName'],
//           "product_alert_email" => $post['notifyEmail'],
//           "customer_id"=> 0,
//           "product_id" => $post['notifyProductId'],
//           //"customer_Product_SubscribedBy" => $post['notifyGuest'],
//           "customer_Product_sendCount" => 0
//         );
//         $logger->info(print_r($data,true));
//         $model =  $this->catalogProductNotificationDetailsFactory
//           ->create();
//           $logger->info(114);
//         $model->addData($data);
//         $saveData = $model->save(); 
//         if ($saveData) {
//           $this->messageManager->addSuccess(__('Alert subscription has been saved. !'));
//           }

    
//         $storeName = \Magento\Framework\App\ObjectManager::getInstance()
//         ->get(\Magento\Store\Model\StoreManagerInterface::class)
//         ->getStore()
//         ->getName();
    
//         $notifycollectionData = $this->catalogProductNotificationDetailsFactory->create()
//         ->getCollection()
//          ->addFieldToFilter('product_alert_email', $post['notifyEmail'])
//         ->getData();
       
//      foreach($notifycollectionData as $notifycollectionDataValue)
//      {
//      $product_notify_details_id =  $notifycollectionDataValue['product_notify_details_id'];

//       $logger->info(print_r($product_notify_details_id,true));
//       $notifyStockcollectionData = $this->catalogProductNotificationFactory->create()
//       ->getCollection()
//       ->addFieldToFilter('product_alert_product_sku', $post['notifyProductSku'])
//       ->getData();

//       $logger->info(print_r($notifyStockcollectionData,true));
    
//       if(empty($notifyStockcollectionData)){
//         $data = array(
//           "product_alert_notify_websites" =>"$storeName",
//           "product_alert_product_name" => $post['notifyProductName'],
//           "product_alert_product_sku" => $post['notifyProductSku'],
//           "product_alert_stock_email" => $post['notifyEmail'],
//            "product_notify_product_id" => $post['notifyProductId'],
//            //"product_alert_noOfSubscription" =>$countEmailData,
//            "product_alert_data_id" => $notifycollectionDataValue['product_notify_details_id'],
//           "product_alert_count" => 0,
//         );
//         $logger->info(print_r($data,true));
    
//         $model =  $this->catalogProductNotificationFactory
//           ->create();
//           $logger->info(138);
//         $model->addData($data);
//         $saveData = $model->save(); 
//         $logger->info(141);
//         if ($saveData) {
//         $this->messageManager->addSuccess(__('Alert subscription- 2 has been saved. !'));
//         }
//       // }else{

//       //   $model = $this->catalogProductNotificationFactory->create();
//       //   $logger->info(252);
//       //   $data = array(
//       //     "product_alert_notify_websites" =>"$storeName",
//       //     "product_alert_product_name" => $post['notifyProductName'],
//       //     "product_alert_product_sku" => $post['notifyProductSku'],
//       //     "product_alert_stock_email" => $post['notifyEmail'],
//       //      "product_notify_product_id" => $post['notifyProductId'],
//       //      "product_alert_noOfSubscription" =>$countEmailData,
//       //    //   "product_alert_data_id" => $notifycollectionDataValue['product_notify_details_id'],
//       //     "product_alert_count" => 0,
//       //   );
//       //   $logger->info(263);
//       //   $logger->info(print_r($data,true));
//       //   $logger->info(265);
//       //   $id = $post['notifyProductId']; //for updating the record
//       //       if ($id) {
//       //           $model->load($id);
//       //       }
//       //   $model->setData($data);
//       //   $model->save();

//       // }
      

        
//       }
//     }
//   }

//   }
//   }
// }





// <?php

// namespace Catalog\Notify\Controller\Product;

// use Zend\Log\Filter\Timestamp;
// use Magento\Framework\App\Action\Context;
// use Magento\Framework\View\Result\PageFactory;
// use Magento\Framework\Controller\Result\JsonFactory;
// use Catalog\Notify\Model\CatalogProductNotificationFactory;
// use Catalog\Notify\Model\CatalogProductNotificationDetailsFactory;
// use Catalog\Notify\Model\CatalogStockNotifyProductFactory;

// use Magento\Framework\Mail\Template\TransportBuilder;
// use Magento\Framework\Translate\Inline\StateInterface;
// use Magento\Framework\App\Config\ScopeConfigInterface;
// use Magento\Store\Model\StoreManagerInterface;
// use Magento\Framework\Escaper;
// use Magento\Catalog\Model\ProductRepository;
// use Magento\Catalog\Api\ProductRepositoryInterface;
// use Psr\Log\LoggerInterface;



// class productNotify extends \Magento\Framework\App\Action\Action
// {

//   protected $productRepositoryInterface;

//     protected $productRepository;

//     protected $resultPageFactory;

//     protected $resultJsonFactory;

//     protected $catalogStockNotifyProductFactory;

//     protected $catalogProductNotificationFactory;

//     protected $catalogProductNotificationDetailsFactory;

//     protected $_transportBuilder;

//     protected $_inlineTranslation;

//     protected $_scopeConfig;

//     protected $storeManager;

//     protected $_escaper;

//     protected $_logLoggerInterface;

//     public function __construct(
//         Context $context,
//         ProductRepository $productRepository,
//         ProductRepositoryInterface $productRepositoryInterface,
//         PageFactory $resultPageFactory,
//         JsonFactory $resultJsonFactory,
//         CatalogProductNotificationFactory  $catalogProductNotificationFactory,
//         CatalogStockNotifyProductFactory  $catalogStockNotifyProductFactory,
//         CatalogProductNotificationDetailsFactory $catalogProductNotificationDetailsFactory,
//         TransportBuilder $transportBuilder,
//         StateInterface $inlineTranslation,
//         ScopeConfigInterface $scopeConfig,
//         StoreManagerInterface $storeManager,
//         LoggerInterface $loggerInterface,
//         Escaper $escaper,
//         array $data = []



//     ) {


//         parent::__construct($context);

//         $this->productRepository = $productRepository;
//         $this->resultPageFactory = $resultPageFactory;
//         $this->resultJsonFactory = $resultJsonFactory;
//         $this->productRepositoryInterface = $productRepositoryInterface;
//         $this->catalogProductNotificationFactory = $catalogProductNotificationFactory;
//         $this->catalogStockNotifyProductFactory = $catalogStockNotifyProductFactory;
//         $this->catalogProductNotificationDetailsFactory = $catalogProductNotificationDetailsFactory;
      
//         $this->_transportBuilder = $transportBuilder;
//         $this->_inlineTranslation = $inlineTranslation;
//         $this->_scopeConfig = $scopeConfig;
//         $this->_logLoggerInterface = $loggerInterface;
//         $this->storeManager = $storeManager;
//         $this->messageManager = $context->getMessageManager();
//         $this->escaper = $escaper;
//     }
//     public function execute()
//     {
//     $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
//     $logger = new \Zend\Log\Logger();
//     $logger->addWriter($writer);

//     $post = $this->getRequest()->getPostValue();

//     $logger->info(print_r($post,true));
      
//     $notifycollectionData = $this->catalogProductNotificationFactory->create()
//     ->getCollection()
//     ->addFieldToFilter('product_alert_stock_email', $post['notifyEmail'])
//     ->addFieldToFilter('product_alert_product_name', $post['notifyProductName'])
//     ->addFieldToFilter('product_alert_product_sku', $post['notifyProductSku']);

//    $productNotifyCollectionAllData =  $notifycollectionData->getData();
//    $logger->info(print_r($productNotifyCollectionAllData,true));

//     if(!empty($productNotifyCollectionAllData)){
//    foreach($productNotifyCollectionAllData as $productNotifyCollectionData){

//         $logger->info(123);
//         $notification_total_count = $productNotifyCollectionData['product_alert_count'];

//         $stockAlertNotifyEmailTotalCount =   $notification_total_count + 1;
      
//         $data = array('product_alert_count' => $stockAlertNotifyEmailTotalCount);
//         $logger->info(129);
       
//         if ($productNotifyCollectionData['product_notify_data_id']) {

//           $logger->info(133);
//           $model =  $this->catalogProductNotificationFactory
//             ->create();
//           $model->load($productNotifyCollectionData['product_notify_data_id']);

//           $model->addData($data);
//           $saveData = $model->save();
//           if ($saveData){
//             $this->messageManager->addSuccess(__(' Thank you! You are already subscribed to this product. !'));
//           }
//         }
//        }
     
//     }else{
     
//       if(empty($post['notifyEmail'])){
//       $this->messageManager->addSuccess(__(' Please Enter Valid Email !'));
      
//       }else{


//         $data = array(
//           "product_alert_first_name" => $post['notifyFirstName'],
//           "product_alert_last_name" => $post['notifyLastName'],
//           "product_alert_email" => $post['notifyEmail'],
//           "customer_id"=> 0,
//           "product_id" => $post['notifyProductId'],
//           //"customer_Product_SubscribedBy" => $post['notifyGuest'],
//           "customer_Product_sendCount" => 0
//         );
//         $logger->info(print_r($data,true));
//         $model =  $this->catalogProductNotificationDetailsFactory
//           ->create();
//           $logger->info(114);
//         $model->addData($data);
//         $saveData = $model->save(); 
//         if ($saveData) {
//           $this->messageManager->addSuccess(__('Alert subscription has been saved. !'));
//           }



//         $storeName = \Magento\Framework\App\ObjectManager::getInstance()
//         ->get(\Magento\Store\Model\StoreManagerInterface::class)
//         ->getStore()
//         ->getName();
    
//         $notifycollectionData = $this->catalogProductNotificationDetailsFactory->create()
//         ->getCollection()
//          ->addFieldToFilter('product_alert_email', $post['notifyEmail'])
//         ->getData();
       
//      foreach($notifycollectionData as $notifycollectionDataValue)
//      {
//      $product_notify_details_id =  $notifycollectionDataValue['product_notify_details_id'];

//       $logger->info(print_r($product_notify_details_id,true));
//       $notifyStockcollectionData = $this->catalogProductNotificationFactory->create()
//       ->getCollection()
//       ->addFieldToFilter('product_alert_product_sku', $post['notifyProductSku'])
//       ->getData();

//       $logger->info(print_r($notifyStockcollectionData,true));
     
//       //$logger->info($countEmailData);
//       if(empty($notifyStockcollectionData)){
//         $data = array(
//           "product_alert_notify_websites" =>"$storeName",
//           "product_alert_product_name" => $post['notifyProductName'],
//           "product_alert_product_sku" => $post['notifyProductSku'],
//           "product_alert_stock_email" => $post['notifyEmail'],
//            "product_notify_product_id" => $post['notifyProductId'],
//            "product_alert_noOfSubscription" =>0,
//           //  "product_alert_noOfSubscription" => $countEmailData,
//            "product_alert_data_id" => $notifycollectionDataValue['product_notify_details_id'],
//           "product_alert_count" => 0,
//         );
//         $logger->info(print_r($data,true));
    
//         $model =  $this->catalogProductNotificationFactory
//           ->create();
//           $logger->info(138);
//         $model->addData($data);
//         $saveData = $model->save(); 
//         $logger->info(141);
//         if ($saveData) {
//         $this->messageManager->addSuccess(__('Alert subscription- 2 has been saved. !'));
//         }
    
        
//       }else{


//         $notifyStockData = $this->catalogProductNotificationFactory->create()
//         ->getCollection()
//         ->addFieldToFilter('product_alert_product_sku', $post['notifyProductSku'])
//         ->getData();
       
//         $logger->info(234);
//         foreach($notifyStockData as $notifyStockValue){
        
//           $product_notify_product_id = $notifyStockValue['product_notify_product_id'];
       
       
//           $notifyStockData = $this->catalogProductNotificationDetailsFactory->create()
//           ->getCollection()
//           ->addFieldToFilter('product_id', $product_notify_product_id)
//           ->getData();
       
//           $countEmailData = count($notifyStockData);
//           $logger->info($countEmailData);
       
       
//           if(!empty($countEmailData)){
//            $logger->info(250);
//             $model = $this->catalogProductNotificationFactory->create();
//             $logger->info(252);
//             $data = array(
//               "product_alert_notify_websites" =>"$storeName",
//               "product_alert_product_name" => $post['notifyProductName'],
//               "product_alert_product_sku" => $post['notifyProductSku'],
//               "product_alert_stock_email" => $post['notifyEmail'],
//                "product_notify_product_id" => $post['notifyProductId'],
//                "product_alert_noOfSubscription" =>$countEmailData,
//              //   "product_alert_data_id" => $notifycollectionDataValue['product_notify_details_id'],
//               "product_alert_count" => 0,
//             );
//             $logger->info(263);
//             $logger->info(print_r($data,true));
//             $logger->info(265);
//             $id = $post['notifyProductId']; //for updating the record
//                 if ($id) {
//                     $model->load($id);
//                 }
//             $model->setData($data);
//             $model->save();
//          // }




//               }
//               }
//       }
//     }
//  }


// die;
//  $notifyStockData = $this->catalogProductNotificationFactory->create()
//  ->getCollection()
//  ->addFieldToFilter('product_alert_product_sku', $post['notifyProductSku'])
//  ->getData();

//  $logger->info(234);
//  foreach($notifyStockData as $notifyStockValue){
 
//    $product_notify_product_id = $notifyStockValue['product_notify_product_id'];


//    $notifyStockData = $this->catalogProductNotificationDetailsFactory->create()
//    ->getCollection()
//    ->addFieldToFilter('product_id', $product_notify_product_id)
//    ->getData();

//    $countEmailData = count($notifyStockData);
//    $logger->info($countEmailData);


//    if(!empty($countEmailData)){
//     $logger->info(250);
//      $model = $this->catalogProductNotificationFactory->create();
//      $logger->info(252);
//      $data = array(
//        "product_alert_notify_websites" =>"$storeName",
//        "product_alert_product_name" => $post['notifyProductName'],
//        "product_alert_product_sku" => $post['notifyProductSku'],
//        "product_alert_stock_email" => $post['notifyEmail'],
//         "product_notify_product_id" => $post['notifyProductId'],
//         "product_alert_noOfSubscription" =>$countEmailData,
//       //   "product_alert_data_id" => $notifycollectionDataValue['product_notify_details_id'],
//        "product_alert_count" => 0,
//      );
//      $logger->info(263);
//      $logger->info(print_r($data,true));
//      $logger->info(265);
//      $id = $post['notifyProductId']; //for updating the record
//          if ($id) {
//              $model->load($id);
//          }
//      $model->setData($data);
//      $model->save();
//    }else{

 
//    }

// }
//      }
//     }


// die;
//    ?>
//  <?php 
// $helper = \Magento\Framework\App\ObjectManager::getInstance()->get('Catalog\Notify\Helper\Data'); 
// if($helper->getCustomerGuestSubscription()) : ?>
// <?php
//       $stockAlertnotifyproductEmail = $post['notifyEmail'];

//       if(!empty($stockAlertnotifyproductEmail)){
      
//         try {
//             $this->_inlineTranslation->suspend();
//             $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

//             $productData = $this->productRepositoryInterface->getById($post['notifyProductId']);

//             $logger->info(print_r(get_class_methods($productData),true));
//               $getProductImage =  $productData->getImage();
//               $getProductUrl =  $productData->getProductUrl();

//             $sender = [
//                 'name' => $post['notifyFirstName'],
//                 'email' => $post['notifyEmail'],
//                 'productName' => $post['notifyProductName'],
//                 'productSku' => $post['notifyProductSku'],
//                 'productImage' =>$getProductImage
//             ];
//             $transport = $this->_transportBuilder
//                 ->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
//                 ->setTemplateOptions(
//                     [
//                         'area' => 'frontend',
//                         'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
//                     ]
//                 )
//                 ->setTemplateVars([
//                     'name'  => $post['notifyFirstName'],
//                     'email'  => $post['notifyEmail'],
//                     'productName' => $post['notifyProductName'],
//                     'productSku' => $post['notifyProductSku'],
//                     'productImage' =>$getProductImage
//                 ])
//                 ->setFrom($sender)
//                 ->addTo($stockAlertnotifyproductEmail)
//                 ->getTransport();

//              $transport->sendMessage();
//             $this->_inlineTranslation->resume();
//             $this->messageManager->addSuccess('Email sent successfully');
          
//         } catch (\Exception $e) {
//             $this->messageManager->addError($e->getMessage());
//             $this->_logLoggerInterface->debug($e->getMessage());
//             exit;
//         }
   
//     }?>
//     <?php// endif; ?>

//     <?php
// /*---Send Email To Admin */
//     $helper = \Magento\Framework\App\ObjectManager::getInstance()->get('Catalog\Notify\Helper\Data'); 
//     if($helper->getSendSubscriptionEmailToAdmin()) : ?>


//     <?php
//             try {
//                     $this->_inlineTranslation->suspend();
//                     $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
                   
//                     $productData = $this->productRepositoryInterface->get($post['notifyProductSku']);
                    
//                      $getProductImage =  $productData->getImage();
//                      $getProductUrl =  $productData->getProductUrl();
                   
//                         $objectManager =\Magento\Framework\App\ObjectManager::getInstance();
//                         $helperImport = $objectManager->get('\Magento\Catalog\Helper\Image');

//                         $imageUrl = $helperImport->init($productData, 'product_page_image_small')
//                                         ->setImageFile($productData->getSmallImage()) // image,small_image,thumbnail
//                                         ->resize(380)
//                                         ->getUrl();
                        
//                        $sender = [
//                         'name'  => $post['notifyFirstName'],
//                         'email'  => $post['notifyEmail'],
//                         'productName' => $post['notifyProductName'],
//                         'productSku' => $post['notifyProductSku'],
//                         'productImage' =>$getProductImage,
//                         'productImageUrl'=>$imageUrl
                       
//                     ];

                 
//                     $transport = $this->_transportBuilder
//                         ->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
//                         ->setTemplateOptions(
//                             [
//                                 'area' => 'frontend',
//                                 'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
//                             ]
//                         )
//                         ->setTemplateVars([
//                             'name'  => $post['notifyFirstName'],
//                             'email'  => $post['notifyEmail'],
//                             'productName' => $post['notifyProductName'],
//                             'productSku' => $post['notifyProductSku'],
//                             'productImage' =>$getProductImage,
//                             'productImageUrl'=>$imageUrl
//                          ])
//                        ->addTo('sk3098940@gmail.com','ravindra')
//                          ->getTransport();

//                      $transport->sendMessage();
//                     $this->_inlineTranslation->resume();
//                     $this->messageManager->addSuccess('Admin Email sent successfully');
                   
               
//                 } catch (\Exception $e) {
//                     $this->messageManager->addError($e->getMessage());
//                     $this->_logLoggerInterface->debug($e->getMessage());
//                     exit;
//                 }

//             ?>
// <?php endif; ?>

//   <?php  }

//   }
// }
// ?>
