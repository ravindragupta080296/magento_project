<?php

namespace Catalog\Notify\Controller\Product;

use Zend\Log\Filter\Timestamp;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;
use Catalog\Notify\Model\CatalogProductNotificationFactory;
use Catalog\Notify\Model\CatalogProductNotificationDetailsFactory;
use Catalog\Notify\Model\CatalogStockNotifyProductFactory;

use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Escaper;
use Magento\Catalog\Model\ProductRepository;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Psr\Log\LoggerInterface;



class productNotify extends \Magento\Framework\App\Action\Action
{

  protected $productRepositoryInterface;

    protected $productRepository;

    protected $resultPageFactory;

    protected $resultJsonFactory;

    protected $catalogStockNotifyProductFactory;

    protected $catalogProductNotificationFactory;

    protected $catalogProductNotificationDetailsFactory;

    protected $_transportBuilder;

    protected $_inlineTranslation;

    protected $_scopeConfig;

    protected $storeManager;

    protected $_escaper;

    protected $_logLoggerInterface;

    public function __construct(
        Context $context,
        ProductRepository $productRepository,
        ProductRepositoryInterface $productRepositoryInterface,
        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory,
        CatalogProductNotificationFactory  $catalogProductNotificationFactory,
        CatalogStockNotifyProductFactory  $catalogStockNotifyProductFactory,
        CatalogProductNotificationDetailsFactory $catalogProductNotificationDetailsFactory,
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        LoggerInterface $loggerInterface,
        Escaper $escaper,
        array $data = []



    ) {


        parent::__construct($context);

        $this->productRepository = $productRepository;
        $this->resultPageFactory = $resultPageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->catalogProductNotificationFactory = $catalogProductNotificationFactory;
        $this->catalogStockNotifyProductFactory = $catalogStockNotifyProductFactory;
        $this->catalogProductNotificationDetailsFactory = $catalogProductNotificationDetailsFactory;
      
        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_scopeConfig = $scopeConfig;
        $this->_logLoggerInterface = $loggerInterface;
        $this->storeManager = $storeManager;
        $this->messageManager = $context->getMessageManager();
        $this->escaper = $escaper;
    }
    public function execute()
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        $post = $this->getRequest()->getPostValue();
        $logger->info(print_r($post, true));

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('product_alert_notify_data');/****** Your table name******/ 
        $sql = "Select * FROM " . $tableName." WHERE  product_notify_product_id = '$post[notifyProductId]'";
    
        $resultSqlNotify = $connection->fetchAll($sql);
        $logger->info(print_r($resultSqlNotify,true));
       
         foreach($resultSqlNotify as $getNotifySingleData){
    
          $product_notify_product_id = $getNotifySingleData['product_notify_product_id'];
    
          //$logger->info(print_r($product_notify_product_id,true));
    
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
          $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
          $connection = $resource->getConnection();
          $tableName = $resource->getTableName('product_alert_notify_details');/****** Your table name******/ 
          $sql = "Select * FROM " . $tableName." WHERE  notify_product_id = '$product_notify_product_id'";
          $resultSqlFetchAllData = $connection->fetchAll($sql);
    
         $logger->info(print_r($resultSqlFetchAllData,true));
    
          $resultSqlNotifyAllData = count($connection->fetchAll($sql));
     
         $logger->info(print_r($resultSqlNotifyAllData,true));
    
         }
       
    
         if(!empty($resultSqlNotifyAllData)){
         $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
         $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
         $connection = $resource->getConnection();
         $tableName = $resource->getTableName('product_alert_notify_data'); //gives table name with 
         $logger->info(135);
         //Update Data into table
         $sql = "Update  " . $tableName." Set  product_alert_count = $resultSqlNotifyAllData where product_notify_product_id = '$post[notifyProductId]'";
         
         $connection->query($sql);
    
        }

                
    if(!empty($post)) {

    $notifyProductId = $post['notifyProductId'];
    $notifyEmail = $post['notifyEmail'];

    $logger->info($notifyProductId);
      $notifycollectionData = $this->catalogProductNotificationDetailsFactory->create()
      ->getCollection()
    ->addFieldToFilter('product_alert_email', $post['notifyEmail'])
      ->addFieldToFilter('notify_product_id', $post['notifyProductId']);

 

 $productNotifyCollectionAllData =  $notifycollectionData->getData();
 $logger->info(print_r($productNotifyCollectionAllData,true));

    if ($productNotifyCollectionAllData) {
        foreach ($productNotifyCollectionAllData as $productNotifyCollectionData) {
            $logger->info(157);
            $logger->info(print_r($productNotifyCollectionData, true));
         
            $logger->info(123);
            $notification_total_count = $productNotifyCollectionData['customer_Product_sendCount'];
      
            $totalNotifyData = $notification_total_count + 1;
      
            $data = ['customer_Product_sendCount'=>$totalNotifyData];
      
            $logger->info(print_r($data, true));
            $logger->info($notification_total_count);
              
            if ($productNotifyCollectionData['product_notify_details_id']) {
                $logger->info(133);
                $model =  $this->catalogProductNotificationDetailsFactory
                  ->create();
                $model->load($productNotifyCollectionData['product_notify_details_id']);
      
                $model->addData($data);
                $saveData = $model->save();
                if ($saveData) {
                    $this->messageManager->addSuccess(__(' Thank you! You are already subscribed to this product. !'));
                }
            }
        }
    } else {
        $data = array(
          "product_alert_first_name" => $post['notifyFirstName'],
          "product_alert_last_name" => $post['notifyLastName'],
          "product_alert_email" => $post['notifyEmail'],
          "customer_id"=> 0,
          "notify_product_id" => $post['notifyProductId'],
          //"customer_Product_SubscribedBy" => $post['notifyGuest'],
          "customer_Product_sendCount" => 0
        );
        //$logger->info(print_r($data,true));
        $model =  $this->catalogProductNotificationDetailsFactory
          ->create();
        $logger->info(114);
        $model->addData($data);
        $saveData = $model->save();
        if ($saveData) {
            $this->messageManager->addSuccess(__('Alert subscription has been saved. !'));
        }




        $storeName = \Magento\Framework\App\ObjectManager::getInstance()
        ->get(\Magento\Store\Model\StoreManagerInterface::class)
          ->getStore()
          ->getName();
          
            $notifycollectionData = $this->catalogProductNotificationDetailsFactory->create()
          ->getCollection()
           ->addFieldToFilter('product_alert_email', $post['notifyEmail'])
          ->getData();
         
            foreach ($notifycollectionData as $notifycollectionDataValue) {
                $product_notify_details_id =  $notifycollectionDataValue['product_notify_details_id'];
  
                $logger->info(print_r($product_notify_details_id, true));
                $notifyStockcollectionData = $this->catalogProductNotificationFactory->create()
            ->getCollection()
            ->addFieldToFilter('product_alert_product_sku', $post['notifyProductSku'])
            ->getData();
      
                $logger->info(print_r($notifyStockcollectionData, true));
      
                if (empty($notifyStockcollectionData)) {
                    $data = array(
            "product_alert_notify_websites" =>"$storeName",
            "product_alert_product_name" => $post['notifyProductName'],
            "product_alert_product_sku" => $post['notifyProductSku'],
            "product_alert_stock_email" => $post['notifyEmail'],
             "product_notify_product_id" => $post['notifyProductId'],
             "product_alert_noOfSubscription" => 1,
             "product_alert_data_id" => $notifycollectionDataValue['product_notify_details_id'],
            "product_alert_count" => 0,
          );
                    //$logger->info(print_r($data,true));
      
                    $model =  $this->catalogProductNotificationFactory
                          ->create();
                    $logger->info(138);
                    $model->addData($data);
                    $saveData = $model->save();
                    $logger->info(141);
                    if ($saveData) {
                        $this->messageManager->addSuccess(__('Alert subscription- 2 has been saved. !'));
                    }
                }
            }

         }
      }
      ?>

      <?php
      /*---Send Email To Admin */
      $helper = \Magento\Framework\App\ObjectManager::getInstance()->get('Catalog\Notify\Helper\Data'); 
      if($helper->getSendSubscriptionEmailToAdmin()) : ?>
  <?php      


      try {
        $this->_inlineTranslation->suspend();
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $productData = $this->productRepositoryInterface->getById($post['notifyProductId']);

        
         $getProductImage =  $productData->getImage();
         $getProductUrl =  $productData->getProductUrl();

          
            $logger->info(print_r($getProductImage,true));
            $logger->info(print_r($getProductUrl,true));

            $objectManager =\Magento\Framework\App\ObjectManager::getInstance();
            $helperImport = $objectManager->get('\Magento\Catalog\Helper\Image');

            $imageUrl = $helperImport->init($productData, 'product_page_image_small')
                            ->setImageFile($productData->getSmallImage()) // image,small_image,thumbnail
                            ->resize(380)
                            ->getUrl();

            $logger->info(print_r($imageUrl,true));
      
        $notifycollectionData = $this->catalogProductNotificationDetailsFactory->create()
        ->getCollection()
         ->addFieldToFilter('product_id', $post['notifyProductSku'])
        ->getData();
      
   

        $sender = [
            'name' => $post['notifyFirstName'],
            'email' => $post['notifyEmail'],
            'productName' => $post['notifyProductName'],
            'productSku' => $post['notifyProductSku'],
            'productImage' =>$getProductImage,
            'productImageUrl'=>$imageUrl,
           // 'SubscriptionTime'=>$notifyCollectionEmailData['stock_alert_first_subscription']
        ];
        $logger->info(print_r($sender,true));
   
        $transport = $this->_transportBuilder
            ->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
            ->setTemplateOptions(
                [
                    'area' => 'frontend',
                    'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                ]
            )
            ->setTemplateVars([
                'name' => $post['notifyFirstName'],
                'email' => $post['notifyEmail'],
                'productName' => $post['notifyProductName'],
                'productSku' => $post['notifyProductSku'],
                'productImage' =>$getProductImage,
                'productImageUrl'=>$imageUrl,
               // 'SubscriptionTime'=>$notifyCollectionEmailData['stock_alert_first_subscription']
            ])
           // ->setFrom('sk3098940@gmail.com')
            ->addTo('sk3098940@gmail.com','ravindra')
           ->getTransport();

         $transport->sendMessage();
        $this->_inlineTranslation->resume();
        $this->messageManager->addSuccess('Admin Email sent successfully');
        //$this->_redirect('localhost/magento2');
        //}
     
    } catch (\Exception $e) {
        $this->messageManager->addError($e->getMessage());
        $this->_logLoggerInterface->debug($e->getMessage());
        exit;
    }
?>

<?php endif; ?>

<?php

    }
  }
   
?>