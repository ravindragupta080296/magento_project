<?php
namespace Catalog\Notify\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    protected $context;

    public function __construct(Context $context)
    {
        $this->context = $context;
        parent::__construct($context);
    }

    public function isEnable()
    {
        return $this->scopeConfig->getValue('catalog_notify/general/enable', ScopeInterface::SCOPE_STORE);
    }
    
    public function getCustomerGuestSubscription()
    {
        return $this->scopeConfig->getValue('catalog_notify/general/customer_guest_subscription', ScopeInterface::SCOPE_STORE);
  
    }
    public function getNotifyEmailTemplates()
    {
       return $this->scopeConfig->getValue('catalog_notify/general/notify_user_templates', ScopeInterface::SCOPE_STORE);
   
    }
    public function getStockAlertQuantityAdmin()
    {
        return $this->scopeConfig->getValue('catalog_notify/general/min_stock_alert_quantity', ScopeInterface::SCOPE_STORE);
     
    }
    public function getSendSubscriptionEmailToAdmin()
    {
        return $this->scopeConfig->getValue('catalog_notify/general/stock_alert_admin_email', ScopeInterface::SCOPE_STORE);
    }

    public function getOutOfStockToInStock()
    {
        return $this->scopeConfig->getValue('catalog_notify/general/stock_alert_productInstock', ScopeInterface::SCOPE_STORE);
    }

}