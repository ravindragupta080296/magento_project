<?php

namespace Catalog\Notify\Controller\Product;

use Zend\Log\Filter\Timestamp;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;
use Catalog\Notify\Model\CatalogProductNotificationFactory;
use Catalog\Notify\Model\CatalogStockNotifyProductFactory;

use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Escaper;
use Magento\Catalog\Model\ProductRepository;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Psr\Log\LoggerInterface;

class productStockAlertNotify extends \Magento\Framework\App\Action\Action
{
    protected $productRepositoryInterface;

    protected $productRepository;

    protected $resultPageFactory;

    protected $resultJsonFactory;

    protected $catalogStockNotifyProductFactory;

    protected $catalogProductNotificationFactory;

    protected $_transportBuilder;

    protected $_inlineTranslation;

    protected $_scopeConfig;

    protected $storeManager;

    protected $_escaper;

    protected $_logLoggerInterface;

    public function __construct(
        Context $context,
        ProductRepository $productRepository,
        ProductRepositoryInterface $productRepositoryInterface,

        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory,
        CatalogProductNotificationFactory  $catalogProductNotificationFactory,
        CatalogStockNotifyProductFactory  $catalogStockNotifyProductFactory,
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        LoggerInterface $loggerInterface,
        Escaper $escaper,
        array $data = []


    ) {

        parent::__construct($context);

        $this->productRepository = $productRepository;
        $this->resultPageFactory = $resultPageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->catalogProductNotificationFactory = $catalogProductNotificationFactory;
        $this->catalogStockNotifyProductFactory = $catalogStockNotifyProductFactory;

        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_scopeConfig = $scopeConfig;
        $this->_logLoggerInterface = $loggerInterface;
        $this->storeManager = $storeManager;
        $this->messageManager = $context->getMessageManager();
        $this->escaper = $escaper;
    }
    public function execute() 
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);

        $logger->info(122);

        $storeName = \Magento\Framework\App\ObjectManager::getInstance()
            ->get(\Magento\Store\Model\StoreManagerInterface::class)
            ->getStore()
            ->getName();

            $post = $this->getRequest()->getPostValue();

            $logger->info(print_r($post,true));




            $poststocknotifyproductId = gettype($post['stocknotifyproductId']);
            $logger->info(print_r($poststocknotifyproductId,true));

            $notifycollectionData = $this->catalogStockNotifyProductFactory->create()
            ->getCollection()
            //->addFieldToFilter('stocknotifyproductEmail', $post['notifyEmail'])
            ->addFieldToFilter('stock_alert_Product_sku', $post['stockNotifyProductSku'])
            ->addFieldToFilter('stocknotifyproductId', $post['stocknotifyproductId'])
            ->getData();

          if(!empty($notifycollectionData)){
        
            foreach($notifycollectionData as $collectionData){

               $stocknotifyproductId = $collectionData['stocknotifyproductId'];

               $stockAlertEmailCount = $collectionData['stock_alert_email_count'];
               $stockAlertEmailTotalCount = $stockAlertEmailCount + 1;

               $logger->info($stockAlertEmailTotalCount);


               $data = array(
                   'customer_awaiting_notification' => $stockAlertEmailTotalCount,
                   'stock_alert_email_count' => 1
               );

               $logger->info(print_r($data,true));

               if ($collectionData['stock_alert_notify_id']) {
                    $model =  $this->catalogStockNotifyProductFactory
                            ->create();

                    $model->load($collectionData['stock_alert_notify_id']);

                    $model->addData($data);
                    $saveData = $model->save();
                    $logger->info(163);
                    if ($saveData) {
                        $this->messageManager->addSuccess(__(' Thank you! You are already subscribed to this product. !'));
                    }

                }

               }
            }else{

                $logger->info(151);


            // // "stock_alert_website" => $storeName,
            // $stocknotifyproductId = $post['stocknotifyproductId'];
            // $stock_alert_product_name = $post['stockNotifyProductName'];
            // $stock_alert_Product_sku = $post['stockNotifyProductSku'];
            // // "customer_awaiting_notification" = 1,
            // $stocknotifyproductEmail = $post['notifyEmail'];
            // // "mail_sent" => 0,
            // // "stock_alert_email_count" = 1,
            // $stock_alert_SubscribedBy= $post['stocknotifyCustomer'];

            // $logger->info(113);
            // $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()
            // ->get('Magento\Framework\App\ResourceConnection');
            // $connection= $this->_resources->getConnection();
            // $logger->info(117);
            // $themeTable = $this->_resources->getTableName('stock_alert_product_notify_data');
            // $sql = "INSERT INTO " . $themeTable . "(stock_alert_website, stocknotifyproductId,stock_alert_product_name,
            // stock_alert_Product_sku,customer_awaiting_notification,stocknotifyproductEmail,mail_sent,
            // stock_alert_email_count,stock_alert_SubscribedBy) VALUES 
            
            // ('$storeName', '$stocknotifyproductId','$stock_alert_product_name','$stock_alert_Product_sku',1,
            // '$stocknotifyproductEmail',0,1,'$stock_alert_SubscribedBy')";

            // $logger->info($sql);

            // $connection->query($sql);

                $data = $this->getRequest()->getParams();

                 $logger->info(print_r($data,true));
               if($data){
              
                $arrayData = array(
                    "stock_alert_website" => $storeName,
                    "stocknotifyproductId" => $data['stocknotifyproductId'],
                    "stock_alert_product_name" => $data['stockNotifyProductName'],
                    "stock_alert_Product_sku" => $data['stockNotifyProductSku'],
                    "customer_awaiting_notification" => 1,
                    "stocknotifyproductEmail" => $data['notifyEmail'],
                    "mail_sent" => 0,
                    "stock_alert_email_count" => 1,
                    "stock_alert_SubscribedBy"=>$data['stocknotifyCustomer']
                );
                $logger->info(print_r($arrayData,true));
                $logger->info(160);
                $model =  $this->catalogStockNotifyProductFactory
                ->create();

                $model->addData(
                [
                    "stock_alert_website" => $storeName,
                    "stocknotifyproductId" => $data['stocknotifyproductId'],
                    "stock_alert_product_name" => $data['stockNotifyProductName'],
                    "stock_alert_Product_sku" => $data['stockNotifyProductSku'],
                    "customer_awaiting_notification" => 1,
                    "stocknotifyproductEmail" => $data['notifyEmail'],
                    "mail_sent" => 0,
                    "stock_alert_email_count" => 1,
                    "stock_alert_SubscribedBy"=>$data['stocknotifyCustomer']
                ]);
                $saveData = $model->save();
                $logger->info(165);
                if ($saveData) {
                  $this->messageManager->addSuccess(__('Insert Stock Alert Record Successfully !'));
                }
            }


        }







                ?>

                <?php 
                $helper = \Magento\Framework\App\ObjectManager::getInstance()->get('Catalog\Notify\Helper\Data'); 
                if($helper->getCustomerGuestSubscription()) : ?>
              <?php  
             $stocknotifyproductEmail = $post['notifyEmail'];

              if(!empty($stocknotifyproductEmail)){
              
                try {
                    $this->_inlineTranslation->suspend();
                    $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

                   $productData = $this->productRepositoryInterface->getById($post['stocknotifyproductId']);

                     //$logger->info(print_r(get_class_methods($productData),true));
                     $getProductImage =  $productData->getImage();
                     $getProductUrl =  $productData->getProductUrl();
                   
                        $logger->info(print_r($getProductImage,true));
                        $logger->info(print_r($getProductUrl,true));

                        $objectManager =\Magento\Framework\App\ObjectManager::getInstance();
                        $helperImport = $objectManager->get('\Magento\Catalog\Helper\Image');

                        $imageUrl = $helperImport->init($productData, 'product_page_image_small')
                                        ->setImageFile($productData->getSmallImage()) // image,small_image,thumbnail
                                        ->resize(380)
                                        ->getUrl();
                     
                    $notifycollectionData = $this->catalogStockNotifyProductFactory->create()
                    ->getCollection()
                     ->addFieldToFilter('stocknotifyproductId', $post['stocknotifyproductId'])
                    ->getData();

                    foreach($notifycollectionData as $notifyCollectionEmailData){
                        
                       $sender = [
                        'name' => $post['notifyFirstName'],
                        'email' => $post['notifyEmail'],
                        'productName' => $post['stockNotifyProductName'],
                        'productSku' => $post['stockNotifyProductSku'],
                        'productImage' =>$getProductImage,
                        'productImageUrl'=>$imageUrl,
                        'SubscriptionTime'=>$notifyCollectionEmailData['stock_alert_first_subscription']
                    ];
                    $transport = $this->_transportBuilder
                        ->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
                        ->setTemplateOptions(
                            [
                                'area' => 'frontend',
                                'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                            ]
                        )
                        ->setTemplateVars([
                            'name'  => $post['notifyFirstName'],
                            'email'  => $post['notifyEmail'],
                            'productName' => $post['stockNotifyProductName'],
                            'productSku' => $post['stockNotifyProductSku'],
                            'productImage' =>$getProductImage,
                            'productImageUrl'=>$imageUrl,
                            'SubscriptionTime'=>$notifyCollectionEmailData['stock_alert_first_subscription']
                        ])
                        ->setFrom($sender)
                        ->addTo($stocknotifyproductEmail)
                        //->addTo('owner@example.com','owner')
                        ->getTransport();

                     $transport->sendMessage();
                    $this->_inlineTranslation->resume();
                    $this->messageManager->addSuccess('Email sent successfully');
                    //$this->_redirect('localhost/magento2');
                    }
                 
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                    $this->_logLoggerInterface->debug($e->getMessage());
                    exit;
                }
            
           
            }?>
         <?php endif; ?>
    <?php
    /*---Send Email To Admin */
    $helper = \Magento\Framework\App\ObjectManager::getInstance()->get('Catalog\Notify\Helper\Data'); 
    if($helper->getSendSubscriptionEmailToAdmin()) : ?>


    <?php
            try {
                    $this->_inlineTranslation->suspend();
                    $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
                    $productData = $this->productRepositoryInterface->getById($post['stocknotifyproductId']);
                     $getProductImage =  $productData->getImage();
                     $getProductUrl =  $productData->getProductUrl();
                   
                        $logger->info(print_r($getProductImage,true));
                        $logger->info(print_r($getProductUrl,true));

                        $objectManager =\Magento\Framework\App\ObjectManager::getInstance();
                        $helperImport = $objectManager->get('\Magento\Catalog\Helper\Image');

                        $imageUrl = $helperImport->init($productData, 'product_page_image_small')
                                        ->setImageFile($productData->getSmallImage()) // image,small_image,thumbnail
                                        ->resize(380)
                                        ->getUrl();
                   
                    $notifycollectionData = $this->catalogStockNotifyProductFactory->create()
                    ->getCollection()
                     ->addFieldToFilter('stocknotifyproductId', $post['stocknotifyproductId'])
                    ->getData();
                  
                    foreach($notifycollectionData as $notifyCollectionEmailData){
                    $sender = [
                        'name' => $post['notifyFirstName'],
                        'email' => $post['notifyEmail'],
                        'productName' => $post['stockNotifyProductName'],
                        'productSku' => $post['stockNotifyProductSku'],
                        'productImage' =>$getProductImage,
                        'productImageUrl'=>$imageUrl,
                        'SubscriptionTime'=>$notifyCollectionEmailData['stock_alert_first_subscription']
                    ];

                 
                    $transport = $this->_transportBuilder
                        ->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
                        ->setTemplateOptions(
                            [
                                'area' => 'frontend',
                                'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                            ]
                        )
                        ->setTemplateVars([
                            'name' => $post['notifyFirstName'],
                            'email' => $post['notifyEmail'],
                            'productName' => $post['stockNotifyProductName'],
                            'productSku' => $post['stockNotifyProductSku'],
                            'productImage' =>$getProductImage,
                            'productImageUrl'=>$imageUrl,
                            'SubscriptionTime'=>$notifyCollectionEmailData['stock_alert_first_subscription']
                        ])
                       // ->setFrom('sk3098940@gmail.com')
                        ->addTo('sk3098940@gmail.com','ravindra')
                       ->getTransport();

                     $transport->sendMessage();
                    $this->_inlineTranslation->resume();
                    $this->messageManager->addSuccess('Admin Email sent successfully');
                    //$this->_redirect('localhost/magento2');
                    }
                 
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                    $this->_logLoggerInterface->debug($e->getMessage());
                    exit;
                }

            ?>
<?php endif; ?>
    <?php    }
   // }
 }


