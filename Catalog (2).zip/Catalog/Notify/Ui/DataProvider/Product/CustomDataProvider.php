<?php /** * Copyright © 2013-2017 Magento, Inc. All rights reserved. * See COPYING.txt for license details. */ 
namespace Catalog\Notify\Ui\DataProvider\Product; 
use Magento\Framework\App\RequestInterface; 
use Magento\Ui\DataProvider\AbstractDataProvider;
use Catalog\Notify\Model\ResourceModel\CatalogProductNotificationDetails\Grid\CollectionFactory; 
use Catalog\Notify\Model\ResourceModel\CatalogProductNotificationDetails\Grid; 
use Catalog\Notify\Model\CatalogProductNotificationDetails;


 
 class CustomDataProvider extends AbstractDataProvider 
 {
     
    /** * @var CollectionFactory */ 
    
    protected $collectionFactory;
    
    /** * @var RequestInterface */ 
    
    protected $request;
    
    /** * @param string $name * @param string $primaryFieldName * @param string $requestFieldName * @param CollectionFactory $collectionFactory * @param RequestInterface $request * @param array $meta * @param array $data */
    
    public function __construct(
        
        $name, $primaryFieldName,
        $requestFieldName, CollectionFactory 
        $collectionFactory, RequestInterface 
        $request, array $meta = [], array $data = []
        
        ) { 
            
        parent::__construct(
            
            $name, $primaryFieldName, $requestFieldName, $meta, $data); 
            
        $this->collectionFactory = $collectionFactory;
        $this->collection = $this->collectionFactory->create();
        $this->request = $request;
    }
 
    /**
     * {@inheritdoc}
     */
    public function getData()
    {


        $this->getCollection();

        $arrItems = [
            'totalRecords' => $this->getCollection()->getSize(),
            'items' => [],
        ];
 
        foreach ($this->getCollection() as $item) {
            $arrItems['items'][] = $item->toArray([]);
        }


       
       
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();  
        $request = $objectManager->get('Magento\Framework\App\Request\Http');  
        $param = $request->getParam('id');

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('product_alert_notify_details'); //gives table name with prefix
      
         $sql = "SELECT * FROM `product_alert_notify_details` WHERE `notify_product_id` = ".$param." ORDER BY 
         product_notify_details_id DESC LIMIT 5";
       
       
          $result = $connection->fetchAll($sql);
            print_r($connection->fetchAll($sql));
         
         return $result;

   
    }
 
    /**
     * {@inheritdoc}
     */
    public function addFilter(\Magento\Framework\Api\Filter $filter)
    {
        $field = $filter->getField();
      
    
        
        if (in_array($field, ['product_notify_details_id','product_alert_first_name','product_alert_last_name','product_alert_email'
                ,'customer_Product_sendCount'])) {
             $filter->setField($field);

           
        }
 
 
 
        parent::addFilter($filter);
    }
}