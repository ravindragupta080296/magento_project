<?php
namespace Catalog\Notify\Ui\DataProvider\Product\Form\Modifier; 
use Magento\Catalog\Model\Locator\LocatorInterface; 
use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier; 
use Magento\Framework\Stdlib\ArrayManager; 
use Magento\Framework\UrlInterface;
use Magento\Ui\Component\Container; 
use Magento\Ui\Component\Form\Fieldset;

class CustomTab extends AbstractModifier 
{
    
    const SAMPLE_FIELDSET_NAME = 'custom_grid_fieldset'; 
    const SAMPLE_FIELD_NAME = 'custom_grid';
    
    protected $_backendUrl; 
    protected $_productloader; 
    protected $_modelCustomgridFactory; 
    
    /** * @var \Magento\Catalog\Model\Locator\LocatorInterface */
    
    protected $locator; 
    /** * @var ArrayManager */
    protected $arrayManager;
    /** * @var UrlInterface */
    protected $urlBuilder; 
    /** * @var array */ 
    protected $meta = []; 
    /** * @param LocatorInterface $locator * @param ArrayManager $arrayManager * @param UrlInterface $urlBuilder */
    
    public function __construct( 
        
        
        LocatorInterface $locator,
        ArrayManager $arrayManager, 
        UrlInterface $urlBuilder, 
        
        \Magento\Catalog\Model\ProductFactory $_productloader,
        \Magento\Backend\Model\UrlInterface $backendUrl
         ) {

        $this->locator = $locator;
        $this->arrayManager = $arrayManager;
        $this->urlBuilder = $urlBuilder;
        $this->_productloader = $_productloader;
        $this->_backendUrl = $backendUrl;
    }
  
    public function modifyData(array $data)
    {
        return $data;
    }
  
    public function modifyMeta(array $meta)
    {
        $this->meta = $meta;
        $this->addCustomTab();
  
        return $this->meta;
    }
  
    protected function addCustomTab()
    {
        $this->meta = array_merge_recursive(
            $this->meta,
            [
                static::SAMPLE_FIELDSET_NAME => $this->getTabConfig(),
            ]
        );
    }
  
    protected function getTabConfig()
    {

    
        $urlInterface = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\UrlInterface');
        $url = $urlInterface->getCurrentUrl();
      
       

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();  
        $request = $objectManager->get('Magento\Framework\App\Request\Http');  
        $param = $request->getParam('id');

      

    return [
        'arguments' => [
            'data' => [
                'config' => [
                    'label' => __('Stock Alert Data'),
                    'componentType' => Fieldset::NAME,
                    'dataScope' => '',
                    'provider' => static::FORM_NAME . '.product_form_data_source',
                    'ns' => static::FORM_NAME,
                    'collapsible' => true,
                ],
            ],
        ],
        'children' => [
            static::SAMPLE_FIELD_NAME => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'autoRender' => true,
                            'componentType' => 'insertListing',
                            'dataScope' => 'product_alert_notify_details_listing_data_source',
                            'externalProvider' => 'catalog_stockdetails_listing.product_alert_notify_details_listing_data_source',
                            'selectionsProvider' => 'catalog_stockdetails_listing.product_alert_notify_details_listing_data_source.product_columns.ids',
                            'ns' => 'catalog_stockdetails_listing',
                           //'render_url' => $this->urlBuilder->getUrl($urlInterface->getCurrentUrl()),
                             'render_url' => $this->urlBuilder->getUrl('mui/index/render/id/'.$request->getParam('id')),
                            'realTimeLink' => false,
                            'behaviourType' => 'simple',
                            'externalFilterMode' => true,
                            'imports' => [
                                'productId' => '${ $.provider }:data.product.current_product_id'
                            ],
                            'exports' => [
                                'productId' => '${ $.externalProvider }:params.current_product_id'
                            ],
 
                        ],
                    ],
                ],
                'children' => [],
            ],
        ],
    ];
    }
 
}