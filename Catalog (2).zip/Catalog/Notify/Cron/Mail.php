<?php

namespace Catalog\Notify\Cron;

use Magento\Framework\Mail\Template\TransportBuilder;
use Zend\Log\Filter\Timestamp;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;
use Catalog\Notify\Model\CatalogProductNotificationFactory;
use Catalog\Notify\Model\CatalogStockNotifyProductFactory;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Escaper;
//use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ProductRepository;
use Psr\Log\LoggerInterface;

class Mail extends \Magento\Framework\App\Action\Action
{

 
  private $logger;
  
  /**
   * @var $TransportBuilder
   */
  private $transportBuilder;

  /**
   * @var $productRepositoryInterface
   */
  
  //protected $productRepositoryInterface;
  protected $_productRepository;
  /**
   * @var $resultPageFactory
   */
  protected $resultPageFactory;
  /**
   * @var $resultJsonFactory
   */
  protected $resultJsonFactory;
  /**
   * @var $catalogStockNotifyProductFactory
   */
  protected $catalogStockNotifyProductFactory;
  /**
   * @var $atalogProductNotificationFactory
   */
  protected $catalogProductNotificationFactory;
   /**
   * @var $_inlineTranslation
   */
  protected $_inlineTranslation;
  /**
   * @var $_scopeConfig
   */
  protected $_scopeConfig;
  /**
   * @var $storeManager
   */
  protected $storeManager;
   /**
   * @var $_escaper
   */
  protected $_escaper;
   /**
   * @var $_logLoggerInterface
   */
  protected $_logLoggerInterface;


  public function __construct(
    TransportBuilder $transportBuilder,
    Context $context,
    ProductRepository $productRepository,
    //ProductRepositoryInterface $productRepositoryInterface,
    PageFactory $resultPageFactory,
    JsonFactory $resultJsonFactory,
    CatalogProductNotificationFactory  $catalogProductNotificationFactory,
    CatalogStockNotifyProductFactory  $catalogStockNotifyProductFactory,
    StateInterface $inlineTranslation,
    ScopeConfigInterface $scopeConfig,
    StoreManagerInterface $storeManager,
    LoggerInterface $loggerInterface,
    Escaper $escaper,
    array $data = []



  ) {
    parent::__construct($context);
  
    $this->transportBuilder = $transportBuilder;
    //$this->productRepositoryInterface = $productRepositoryInterface;
    $this->_productRepository = $productRepository;
    $this->resultPageFactory = $resultPageFactory;
    $this->resultJsonFactory = $resultJsonFactory;
    $this->catalogProductNotificationFactory = $catalogProductNotificationFactory;
    $this->catalogStockNotifyProductFactory = $catalogStockNotifyProductFactory;
    $this->_inlineTranslation = $inlineTranslation;
    $this->_scopeConfig = $scopeConfig;
    $this->_logLoggerInterface = $loggerInterface;
    $this->storeManager = $storeManager;
    $this->messageManager = $context->getMessageManager();
    $this->escaper = $escaper;
  }

 
  public function execute()
  {

    $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
    $logger = new \Zend\Log\Logger();
    $logger->addWriter($writer);
    $logger->info(114);
    ?><?php
    $helper = \Magento\Framework\App\ObjectManager::getInstance()->get('Catalog\Notify\Helper\Data'); 
    if($helper->getNotifyEmailTemplates()) :?>


<?php
  $productGetDataCollection = $this->catalogStockNotifyProductFactory
  ->create()
  ->getCollection()
  ->getData();

  $logger->info(print_r($productGetDataCollection,true));

  foreach($productGetDataCollection as $productGetData){

    $productCollectionSku = $productGetData['stock_alert_Product_sku'];
    $productStocknotifyproductId = $productGetData['stocknotifyproductId'];
    $logger->info(print_r($productCollectionSku,true));

    $allProductData = $this->_productRepository->get($productCollectionSku);
    $logger->info(print_r($allProductData,true));

    foreach($allProductData as $productData){
      $logger->info(print_r($productData,true));
    }
  }
 
?>
 
    <?php
    $productGetData = $this->catalogStockNotifyProductFactory
      ->create()
      ->getCollection()
      ->addFieldToFilter('mail_sent', 0)
      ->getData();
     
    

    foreach ($productGetData as $sentEmailNotify) {

      $pId = $sentEmailNotify['stock_alert_notify_id'];
      $productWebsite = $sentEmailNotify['stock_alert_website'];
      $productName = $sentEmailNotify['stock_alert_product_name'];
      $productSku = $sentEmailNotify['stock_alert_Product_sku'];
      $productEmailCount =  $sentEmailNotify['stock_alert_email_count'];
      $productAwaitingNotification =  $sentEmailNotify['customer_awaiting_notification'];
      $productId = $sentEmailNotify['stocknotifyproductId'];
      $productEmail = $sentEmailNotify['stocknotifyproductEmail'];

      $productEmailCount =  $sentEmailNotify['stock_alert_email_count'];

      $logger->info($productEmailCount);
   
      $emailCount = $productEmailCount - 1;
      $productAwaitingNotification = $productAwaitingNotification - 1;

      $productData = $this->productRepositoryInterface->getById($productId);
      $logger->info(print_r(get_class_methods($productData),true));
        $getProductStockData = $productData->getQty();
        $logger->info($getProductStockData);
       $gateProductImage = $productData->getProductUrl();
       $logger->info(print_r($gateProductImage,true));
     
        ?><?php
        $helper = \Magento\Framework\App\ObjectManager::getInstance()->get('Catalog\Notify\Helper\Data'); 
        if($helper->getStockAlertQuantityAdmin()) :?>
        <?php

            $getStockAlertQuantityAdmin = $helper->getStockAlertQuantityAdmin();
           

            if($getStockAlertQuantityAdmin >= $getProductStockData){
              $logger->info(1);
              if (!empty($productData)) {
                $logger->info(2);
                if (!$productData->isAvailable()) {
                  $model =  $this->catalogStockNotifyProductFactory
                    ->create();
                  $data = array(
                   'mail_sent' => 1,
                   'customer_awaiting_notification'=>$productAwaitingNotification,
                   'stock_alert_email_count'=>$emailCount);
        
                  $model->load($sentEmailNotify['stock_alert_notify_id']);
        
                  $model->addData($data);
                  $saveData = $model->save();
                if ($saveData) {
                    $logger->info('Updated Data Successfully');
                  }
                  try {
        
                    $this->_inlineTranslation->suspend();
                    $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
                    $logger->info(3);
                    $sender = [
                      'name' => $sentEmailNotify['stock_alert_product_name'],
                      'email' => $sentEmailNotify['stocknotifyproductEmail'],
                      'productName' => $sentEmailNotify['stock_alert_product_name'],
                      'productSku' => $sentEmailNotify['stock_alert_Product_sku'],
                    ];
                    $logger->info(4);
                    $logger->info(print_r($sender,true));
                    $transport = $this->transportBuilder->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
                      ->setTemplateOptions([
                        'area' => 'frontend',
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                      ]);
                      $transport->setTemplateVars($sender);
                      $logger->info(5);
                      $transport->setFrom($sender);
                      $transport->addTo($sentEmailNotify['stocknotifyproductEmail']);
                      $logger->info(6);
                      $transport->setReplyTo($sentEmailNotify['stocknotifyproductEmail']);
                     
                      $transport->getTransport();
                      $logger->info(7);
                    $transport->sendMessage();
                    $logger->info('Email Successfully send');
        
                    $this->logger->info('Cron Works');
        
                    return $this;
                  } catch (Exception $e) {
                    $this->logger->error($e);
                  }
                }
              }else {
                $logger->info(275);
              }

            }
            
 ?>

         
           <?php  if (!empty($productData)) {
                if (!$productData->isAvailable()) {
                  $model =  $this->catalogStockNotifyProductFactory
                    ->create();
                  $data = array(
                   'mail_sent' => 1,
                   'customer_awaiting_notification'=>$productAwaitingNotification,
                   'stock_alert_email_count'=>$emailCount);
        
                  $model->load($sentEmailNotify['stock_alert_notify_id']);
        
                  $model->addData($data);
                  $saveData = $model->save();
                if ($saveData) {
                    $logger->info('Updated Data Successfully');
                  }
                  try {
        
                    $this->_inlineTranslation->suspend();
                    $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        
                    $sender = [
                      'name' => $sentEmailNotify['stock_alert_product_name'],
                      'email' => $sentEmailNotify['stocknotifyproductEmail'],
                      'productName' => $sentEmailNotify['stock_alert_product_name'],
                      'productSku' => $sentEmailNotify['stock_alert_Product_sku'],
                    ];
        
                    $logger->info(print_r($sender,true));
                    $transport = $this->transportBuilder->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
                      ->setTemplateOptions([
                        'area' => 'frontend',
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                      ]);
                      $transport->setTemplateVars($sender);
                      $logger->info(184);
                      $transport->setFrom($sender);
                      $transport->addTo('ravindrag488@gmail.com');
                      $logger->info(187);
                      $transport->setReplyTo('sk3098940@gmail.com');
                      $logger->info(189);
                      $transport->getTransport();
                      $logger->info(190);
                    $transport->sendMessage();
                    $logger->info('Email Successfully send');
        
                    $this->logger->info('Cron Works');
        
                    return $this;
                  } catch (Exception $e) {
                    $this->logger->error($e);
                  }
                }
              }
           

            $logger->info(213);
            
           /* if($getStockAlertQuantityAdmin >= $getProductStockData){
              $logger->info(1);
              if (!empty($productData)) {
                $logger->info(2);
                if (!$productData->isAvailable()) {
                  $model =  $this->catalogStockNotifyProductFactory
                    ->create();
                  $data = array(
                   'mail_sent' => 1,
                   'customer_awaiting_notification'=>$productAwaitingNotification,
                   'stock_alert_email_count'=>$emailCount);
        
                  $model->load($sentEmailNotify['stock_alert_notify_id']);
        
                  $model->addData($data);
                  $saveData = $model->save();
                if ($saveData) {
                    $logger->info('Updated Data Successfully');
                  }
                  try {
        
                    $this->_inlineTranslation->suspend();
                    $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
                    $logger->info(3);
                    $sender = [
                      'name' => $sentEmailNotify['stock_alert_product_name'],
                      'email' => $sentEmailNotify['stocknotifyproductEmail'],
                      'productName' => $sentEmailNotify['stock_alert_product_name'],
                      'productSku' => $sentEmailNotify['stock_alert_Product_sku'],
                    ];
                    $logger->info(4);
                    $logger->info(print_r($sender,true));
                    $transport = $this->transportBuilder->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
                      ->setTemplateOptions([
                        'area' => 'frontend',
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                      ]);
                      $transport->setTemplateVars($sender);
                      $logger->info(5);
                      $transport->setFrom($sender);
                      $transport->addTo('ravindrag488@gmail.com');
                      $logger->info(6);
                      $transport->setReplyTo('sk3098940@gmail.com');
                     
                      $transport->getTransport();
                      $logger->info(7);
                    $transport->sendMessage();
                    $logger->info('Email Successfully send');
        
                    $this->logger->info('Cron Works');
        
                    return $this;
                  } catch (Exception $e) {
                    $this->logger->error($e);
                  }
                }
              }else {
                $logger->info(275);
              }

            }
           */
        ?>
 <?php endif; ?>
<?php
    }
    ?>
    <?php endif; ?>
    <?php
  }

  }
