<?php

namespace Catalog\Notify\Observer;

use Magento\Framework\Event\ObserverInterface;

class ProductSaveAfter implements ObserverInterface
{
    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;
    protected $_orderRepositoryInterface;
    protected $_transportBuilder;
    protected $_inlineTranslation;
    protected $storeManager;
    protected $catalogStockNotifyProductFactory;
    protected $catalogProductNotificationFactory;



    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepositoryInterface,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
         \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
         \Magento\Store\Model\StoreManagerInterface $storeManager,
         \Catalog\Notify\Model\CatalogProductNotificationFactory $catalogProductNotificationFactory,
         \Catalog\Notify\Model\CatalogStockNotifyProductFactory $catalogStockNotifyProductFactory
    ) {
        $this->_objectManager = $objectManager;
        $this->_orderRepositoryInterface = $orderRepositoryInterface;
        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
        $this->storeManager = $storeManager;
        $this->catalogProductNotificationFactory = $catalogProductNotificationFactory;
        $this->catalogStockNotifyProductFactory = $catalogStockNotifyProductFactory;

    }

    /**
     * customer register event handler
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info(33);
        ?>

        <?php 
                $helper = \Magento\Framework\App\ObjectManager::getInstance()->get('Catalog\Notify\Helper\Data'); 
                if($helper->getOutOfStockToInStock()) : ?>
         <?php       
        $_product = $observer->getProduct();  // you will get product object
            
        //$logger->info(print_r(get_class_methods($_product),true));
        $_productSku=$_product->getSku(); // for sku
        $_productName=$_product->getName(); // for sku
        $_productImage=$_product->getImage(); // for skugetProductUrl
        $productStockAvailableOrNot = $_product->isInStock();
        $getQuantityAndStockStatus =  $_product->getQuantityAndStockStatus();
        $getQty =  $_product->getQty();

        $logger->info($getQuantityAndStockStatus['is_in_stock']);


        $notifycollectionData = $this->catalogStockNotifyProductFactory->create()
        ->getCollection()
        ->addFieldToFilter('stock_alert_Product_sku', $_productSku)
        ->addFieldToFilter('stock_alert_product_name', $_productName)
        ->getData();

        $logger->info(print_r($notifycollectionData,true));

       foreach($notifycollectionData as $notifycollectionDataValue){
        $stocknotifyproductEmail = $notifycollectionDataValue['stocknotifyproductEmail'];
        $stock_alert_product_name = $notifycollectionDataValue['stock_alert_product_name'];
        $stock_alert_Product_sku = $notifycollectionDataValue['stock_alert_Product_sku'];


        if(!empty($getQuantityAndStockStatus['is_in_stock'])){

            $sender = array(
                'name'  => '',
                'email'  => '',
                'productName' => $_productName,
                'productSku' => $_productSku,
                'productImage' =>$_productImage,
                'productImageUrl'=>'',
                'SubscriptionTime'=>''
            );
    
            $logger->info(print_r($sender,true));
            // $customer_email = 'ravindrag488@gmail.com';
            $customer_name = 'ravindra gupta';
    
            $sender = [    
                'email' =>$stocknotifyproductEmail,
                'name' => $customer_name
              ];
    
              $logger->info(print_r($sender,true));
            //  $to_email = $this->_helper->getSendMailTo();
    
            $transport= $this->_transportBuilder->setTemplateIdentifier('catalog_notify_general_notify_user_templates')
                    ->setTemplateOptions( 
                        [
                            'area' => 'frontend',
                            'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                        ])
                         ->setTemplateVars([
                            'name'  => $customer_name,
                            'email'  => $stocknotifyproductEmail,
                            'productName' => $_productName,
                            'productSku' => $_productSku,
                            'productImage' => $_productImage,
                          ])
                    ->setFrom($sender)
                    ->addTo($stocknotifyproductEmail,$customer_name)
                    ->getTransport();
    
                $transport->sendMessage();
                // $this->_inlineTranslation->resume();
                // $this->messageManager->addSuccess('Admin Email sent successfully');

            
            
            try {
                $model = $this->catalogStockNotifyProductFactory->create();
                $model->load($stocknotifyproductEmail);
                $model->delete();
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }


            }

       }
       ?>
       <?php endif; ?>
       <?php
       
   }
}
?>

